# Car-Simulation-Game
Car Simulation game using HTML CSS and JavaScript
# Why This?
Coz I was getting bored yesterday. So I thought to create something nice.
# Is this nice?
For me, Yes it is!
# You made project on HTML, that's not a programming language! LOL..
So what !? And Programming is done using JavaScript.
# Technologies Used
HTML 
CSS 
JavaScript
